import csv
lista = [] #matriz multidimensional
nota = [] #notas
tia = [] #tias
#----contadores de pessoas de acordo com final do tia
cont0a3 = 0
cont4a6 = 0
cont7a9 = 0
#------contador de aprovados e  reprovados
aprovados = 0
reprovados = 0
#----tia final 0 a 3-----
pnota0a20 = 0
pnota20a40 = 0
pnota40a60 = 0
pnota60a80 = 0
pnota80a100 = 0
#----tia final 4 a 6-----
snota0a20 = 0
snota20a40 = 0
snota40a60 = 0
snota60a80 = 0
snota80a100 = 0
#----tia final 7 a 9-----
tnota0a20 = 0
tnota20a40 = 0
tnota40a60 = 0
tnota60a80 = 0
tnota80a100 = 0
#------ variavel para o calculo percentual das notas
p1 = 0
p2 = 0
p3 = 0
p4 = 0
p5 = 0
p6 = 0
p7 = 0
p8 = 0
p9 = 0
p10 = 0
p11 = 0
p12 = 0
p13 = 0
p14 = 0
p15 = 0

with open('inscritos e notas.csv', newline='') as csvfile:
    arquivo = csv.reader(csvfile, delimiter=';')
    for linha in arquivo:
        lista.append(linha)
    #adicionar tias na lista
    for t in range (0, 100000):
        tia.append(str(lista[t][0]))
    #adicionar notas na lista
    for n in range (0, 100000):
        nota.append(float(lista[n][1]))
    #inverter TIA e conseguir o primeiro elemento do mesmo para a verificacao de notas
    for x in range (0, 100000):
        digito = (tia[x][::-1])
#--------------------------------------------------
        if (digito[0])=='0' or (digito[0])=='1' or (digito[0])=='2' or (digito[0])=='3':
            #contabilizar aprovados
            if nota[x]>=70:
                aprovados+=1
            #percentual de candidatos
            if 0<nota[x]<=20:
                p1 = p1+nota[x]
                pnota0a20+= 1
            if 20<nota[x]<=40:
                p2 = p2+nota[x]
                pnota20a40+= 1
            if 40<nota[x]<=60:
                p3 = p3+nota[x]
                pnota40a60+= 1
            if 60<nota[x]<=80:
                p4 = p4+nota[x]
                pnota60a80+= 1
            if 80<nota[x]<=100:
                p5 = p5+nota[x]
                pnota80a100+= 1
            cont0a3+= 1
#--------------------------------------------------
        if (digito[0])=='4' or (digito[0])=='5' or (digito[0])=='6':
            #contabilizar reprovados
            if nota[x]<75:
                reprovados+=1
            #percentual de candidatos
            if 0<nota[x]<=20:
                p6 = p6+nota[x]
                snota0a20+= 1
            if 20<nota[x]<=40:
                p7 = p7+nota[x]
                snota20a40+= 1
            if 40<nota[x]<=60:
                p8 = p8+nota[x]
                snota40a60+= 1
            if 60<nota[x]<=80:
                p9 = p9+nota[x]
                snota60a80+= 1
            if 80<nota[x]<=100:
                p10 = p10+nota[x]
                snota80a100+= 1
            cont4a6+=1
#--------------------------------------------------
        if (digito[0])=='7' or (digito[0])=='8' or (digito[0])=='9':
            #percentual de candidatos
            if 0<nota[x]<=20:
                p11 = p11+nota[x]
                tnota0a20+= 1
            if 20<nota[x]<=40:
                p12 = p12+nota[x]
                tnota20a40+= 1
            if 40<nota[x]<=60:
                p13 = p13+nota[x]
                tnota40a60+= 1
            if 60<nota[x]<=80:
                p14 = p14+nota[x]
                tnota60a80+= 1
            if 80<nota[x]<=100:
                p15 = p15+nota[x]
                tnota80a100+= 1
            cont7a9+=1
#--------------------------------------------------
#exercicio 1 aprovados e reprovados
print ("O total de aprovados com o TIA terminado nos numeros de 0 a 3 sao:",aprovados)
print ("------------------------------------------------------------------------------------------------")
print ("O total de reprovados com o TIA terminado nos numeros de 4 a 6 sao:",reprovados)
print ("------------------------------------------------------------------------------------------------")
#exercicio 2 percentual 
print ("Percentual de candidatos que obtiveram:\n")
print ("Pessoas com TIAs final 0 a 3:",cont0a3,"\n")
print ("notas de 0 a 20,00:",(pnota0a20/cont0a3)*100,"%")
print ("notas de 20.1 a 40,00:",(pnota20a40/cont0a3)*100,"%")
print ("notas de 40.1 a 60,00:",(pnota40a60/cont0a3)*100,"%")
print ("notas de 60.1 a 80,00:",(pnota60a80/cont0a3)*100,"%")
print ("notas de 80.1 a 100,00:",(pnota80a100/cont0a3)*100,"%\n")
print ("Pessoas com TIAs final 4 a 6:",cont4a6,"\n")
print ("notas de 0 a 20,00:",(snota0a20/cont4a6)*100,"%")
print ("notas de 20.1 a 40,00:",(snota20a40/cont4a6)*100,"%")
print ("notas de 40.1 a 60,00:",(snota40a60/cont4a6)*100,"%")
print ("notas de 60.1 a 80,00:",(snota60a80/cont4a6)*100,"%")
print ("notas de 80.1 a 100,00:",(snota80a100/cont4a6)*100,"%\n")
print ("Pessoas com TIAs final 7 a 9:",cont7a9,"\n")
print ("notas de 0 a 20,00:",(tnota0a20/cont7a9)*100,"%")
print ("notas de 20.1 a 40,00:",(tnota20a40/cont7a9)*100,"%")
print ("notas de 40.1 a 60,00:",(tnota40a60/cont7a9)*100,"%")
print ("notas de 60.1 a 80,00:",(tnota60a80/cont7a9)*100,"%")
print ("notas de 80.1 a 100,00:",(tnota80a100/cont7a9)*100,"%")



            



