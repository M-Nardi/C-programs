#include <cstdlib>
#include <iostream>
#include "Pilha.h" 

using namespace std;

// ----------------- Funcao main
int main(){
    Pilha s;
    int numLido;
    
    if (s.eVazia())
        cout << "Pilha esta vazia\n";
    else
        cout << "Pilha nao esta vazia\n";
        
    while (true){
        cout << "\n-Digite 0 para sair.\n -Digite 1 para empilhar um elemento. \n -Digite 2 para desempilhar um elemento. \n -Digite 3 para consultar a capacidade da pilha. \n -Digite 4 para consultar o elemento do topo. \n -Digite 5 para esvaziar a pilha. \n\n Opcao:";
        cin >> numLido;
        if (numLido == 0)
            break;
        else if (numLido == 1){
			cout << "Digite o numero a ser empilhado: ";
			cin >> numLido;
			cout << endl;
        if (s.empilha(numLido)){
        	cout << "O numero foi empilhado \n";
        	
        }
        else{
            cout << "Pilha cheia: numero ignorado.\n";
        }
    }
    	else if (numLido == 2){
    		if (!s.eVazia()){
    			int aux;
    			s.desempilha(aux);
    			cout << aux << " Foi desempilhado\n";
			}
    		else{
    			cout << "Nao ha elementos para se desempilhar";
    			
    		}	
		}
		
		else if (numLido == 3){
			int Restante;
			s.consultar(Restante);
			cout << "Ha " << Restante << " posicoes restantes de " << TAM << " posicoes." << endl;
		}
		
		else if (numLido == 4){
			int valorTopo;
			s.consultarTopo(valorTopo);
			cout << "O elemento topo e:" << valorTopo << endl;
		}
		
		else if (numLido == 5){
			int Restante;
			s.consultar(Restante);
			int cont = 1;
			for (int i=0; TAM>i; i++){
				if (!s.eVazia()){
    			int aux;
    			s.desempilha(aux);
				cout << aux << " numero apagado. \n";
				}
			}
			cout << " Pilha esvaziada\n";	
		}
		
		
		
}
    while (!s.eVazia()){
        int aux;
        s.desempilha(aux);
        cout << aux << ' ';
    }
    system("PAUSE");
    return 0;
}
